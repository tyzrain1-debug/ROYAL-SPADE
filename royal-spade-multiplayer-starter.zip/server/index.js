const express = require("express");
const http = require("http");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { Server } = require("socket.io");
const { startHand, advance, settle, publicRoom } = require("./poker");

const app = express();
const server = http.createServer(app);
const origin = process.env.CLIENT_ORIGIN || "http://localhost:5173";
app.use(cors({ origin, credentials: true }));
app.use(express.json());
const SECRET = process.env.JWT_SECRET || "DEV_ONLY_CHANGE_THIS_SECRET";
const users = new Map();
const rooms = new Map();
const sockets = new Map();
let nextRoom = 1;

function tokenFor(user) { return jwt.sign({id:user.id,name:user.name}, SECRET, {expiresIn:"7d"}); }
function auth(req,res,next) {
  try { req.user = jwt.verify((req.headers.authorization||"").replace("Bearer ",""), SECRET); next(); }
  catch { res.status(401).json({error:"Please sign in"}); }
}
app.get("/api/health", (_,res)=>res.json({ok:true,service:"Royal Spade"}));
app.post("/api/register", async (req,res)=>{
  const {name,password}=req.body||{};
  if(!name || name.length<3 || !password || password.length<8) return res.status(400).json({error:"Nickname must be 3+ characters and password 8+ characters"});
  if([...users.values()].some(u=>u.name.toLowerCase()===name.toLowerCase())) return res.status(409).json({error:"Nickname already exists"});
  const user={id:crypto.randomUUID(),name,password:await bcrypt.hash(password,10),chips:100000,history:[]};
  users.set(user.id,user); res.json({token:tokenFor(user),user:{id:user.id,name:user.name,chips:user.chips}});
});
app.post("/api/login", async (req,res)=>{
  const {name,password}=req.body||{};
  const user=[...users.values()].find(u=>u.name.toLowerCase()===String(name||"").toLowerCase());
  if(!user || !await bcrypt.compare(password||"",user.password)) return res.status(401).json({error:"Invalid nickname or password"});
  res.json({token:tokenFor(user),user:{id:user.id,name:user.name,chips:user.chips}});
});
app.get("/api/me",auth,(req,res)=>{
  const u=users.get(req.user.id); if(!u) return res.status(404).json({error:"Account not found"});
  res.json({id:u.id,name:u.name,chips:u.chips,history:u.history.slice(-30).reverse()});
});
app.get("/api/rooms",(_,res)=>res.json([...rooms.values()].map(r=>({id:r.id,name:r.name,game:r.game,players:r.players.length,maxPlayers:r.maxPlayers,buyIn:r.buyIn,stage:r.stage}))));
app.get("/",(_,res)=>res.sendFile(require("path").join(__dirname,"../dist/index.html")));

const io = new Server(server,{cors:{origin,methods:["GET","POST"]}});
io.use((socket,next)=>{
  try {
    const decoded=jwt.verify(socket.handshake.auth?.token,SECRET);
    const user=users.get(decoded.id); if(!user) return next(new Error("Account not found"));
    socket.user={id:user.id,name:user.name}; next();
  } catch { next(new Error("Sign in required")); }
});
function emitRoom(room) {
  room.players.forEach(p=>{ const s=sockets.get(p.id); if(s) s.emit("room:update",publicRoom(room,p.id)); });
  io.emit("lobby:update",[...rooms.values()].map(r=>({id:r.id,name:r.name,game:r.game,players:r.players.length,maxPlayers:r.maxPlayers,buyIn:r.buyIn,stage:r.stage})));
}
function current(room) { return room.players[room.turn]; }
io.on("connection",socket=>{
  const uid=socket.user.id; sockets.set(uid,socket);
  socket.on("room:create",(data,cb)=>{
    const user=users.get(uid); const buyIn=Math.max(2000,Math.min(200000,Number(data?.buyIn)||5000));
    if(user.chips<buyIn) return cb?.({error:"Not enough virtual chips"});
    const room={id:String(nextRoom++),name:data?.name||"Royal Table",game:"Texas Hold'em",buyIn,maxPlayers:6,smallBlind:Math.floor(buyIn/100),bigBlind:Math.floor(buyIn/50),players:[],dealer:-1,turn:-1,pot:0,stage:"waiting",acted:new Set()};
    rooms.set(room.id,room); joinRoom(socket,room,cb);
  });
  socket.on("room:join",(id,cb)=>{ const room=rooms.get(String(id)); if(!room) return cb?.({error:"Table not found"}); joinRoom(socket,room,cb); });
  socket.on("player:action",(action,cb)=>{
    const room=[...rooms.values()].find(r=>r.players.some(p=>p.id===uid));
    if(!room) return cb?.({error:"You are not seated"});
    if(room.turn<0 || current(room)?.id!==uid) return cb?.({error:"It is not your turn"});
    const p=current(room); const type=action?.type;
    if(type==="fold") p.folded=true;
    else if(type==="check" && p.bet!==room.currentBet) return cb?.({error:"You cannot check; call or fold"});
    else if(type==="call") { const n=Math.min(p.stack,room.currentBet-p.bet); p.stack-=n;p.bet+=n;room.pot+=n; }
    else if(type==="raise") {
      const target=Math.max(room.currentBet+room.bigBlind,Number(action.amount)||room.currentBet+room.bigBlind);
      const n=Math.min(p.stack,Math.max(0,target-p.bet)); if(n<=0) return cb?.({error:"Invalid raise"});
      p.stack-=n;p.bet+=n;room.pot+=n;room.currentBet=p.bet;
    } else if(type!=="check") return cb?.({error:"Unknown action"});
    room.acted.add(uid);
    const live=room.players.filter(x=>!x.folded);
    if(live.length===1) settle(room);
    else {
      const active=room.players.filter(x=>!x.folded && x.stack>0);
      const allMatched=active.every(x=>x.bet===room.currentBet);
      if(allMatched && active.every(x=>room.acted.has(x.id))) advance(room);
      else {
        let idx=room.turn, tries=0;
        do { idx=(idx+1)%room.players.length; tries++; } while((room.players[idx].folded || room.players[idx].stack===0 || room.acted.has(room.players[idx].id)) && tries<=room.players.length);
        room.turn=idx;
      }
    }
    emitRoom(room); cb?.({ok:true});
  });
  socket.on("disconnect",()=>{ sockets.delete(uid); });
});
function joinRoom(socket,room,cb) {
  const uid=socket.user.id, user=users.get(uid);
  if(room.players.some(p=>p.id===uid)) return cb?.({ok:true,room:publicRoom(room,uid)});
  if(room.players.length>=room.maxPlayers) return cb?.({error:"Table is full"});
  if(user.chips<room.buyIn) return cb?.({error:"Not enough virtual chips"});
  user.chips-=room.buyIn;
  room.players.push({id:uid,name:user.name,stack:room.buyIn,cards:[],bet:0,folded:false});
  user.history.push({type:"table buy-in",amount:-room.buyIn,at:new Date().toISOString()});
  socket.join(room.id);
  if(room.players.length>=2 && room.stage==="waiting") startHand(room);
  emitRoom(room); cb?.({ok:true,room:publicRoom(room,uid)});
}
const PORT=process.env.PORT||3001;
server.listen(PORT,()=>console.log(`Royal Spade server listening on ${PORT}`));

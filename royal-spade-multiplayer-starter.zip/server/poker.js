const SUITS = ["♠", "♥", "♦", "♣"];
const RANKS = ["2","3","4","5","6","7","8","9","10","J","Q","K","A"];
const value = r => RANKS.indexOf(r) + 2;

function deck() {
  const cards = SUITS.flatMap(s => RANKS.map(r => ({ r, s })));
  for (let i = cards.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [cards[i], cards[j]] = [cards[j], cards[i]];
  }
  return cards;
}
const take = (d, n) => Array.from({length:n}, () => d.pop());

function combinations(items, k) {
  if (k === 0) return [[]];
  if (items.length < k) return [];
  return [
    ...combinations(items.slice(1), k - 1).map(x => [items[0], ...x]),
    ...combinations(items.slice(1), k)
  ];
}
function scoreFive(cards) {
  const vals = cards.map(c => value(c.r)).sort((a,b) => b-a);
  const counts = {};
  vals.forEach(v => counts[v] = (counts[v] || 0) + 1);
  const groups = Object.entries(counts).map(([v,n]) => [n, Number(v)]).sort((a,b) => b[0]-a[0] || b[1]-a[1]);
  const flush = cards.every(c => c.s === cards[0].s);
  const unique = [...new Set(vals)].sort((a,b) => b-a);
  let straight = 0;
  if (unique.length === 5 && unique[0] - unique[4] === 4) straight = unique[0];
  if (unique.join(",") === "14,5,4,3,2") straight = 5;
  if (flush && straight) return [8, straight];
  if (groups[0][0] === 4) return [7, groups[0][1], groups[1][1]];
  if (groups[0][0] === 3 && groups[1][0] === 2) return [6, groups[0][1], groups[1][1]];
  if (flush) return [5, ...vals];
  if (straight) return [4, straight];
  if (groups[0][0] === 3) return [3, groups[0][1], ...groups.slice(1).map(x=>x[1])];
  if (groups[0][0] === 2 && groups[1][0] === 2) return [2, Math.max(groups[0][1],groups[1][1]), Math.min(groups[0][1],groups[1][1]), groups[2][1]];
  if (groups[0][0] === 2) return [1, groups[0][1], ...groups.slice(1).map(x=>x[1])];
  return [0, ...vals];
}
function compare(a,b) {
  for (let i=0;i<Math.max(a.length,b.length);i++) {
    const d=(a[i]||0)-(b[i]||0); if(d) return d;
  }
  return 0;
}
function handScore(cards) {
  return combinations(cards,5).map(scoreFive).sort(compare).at(-1);
}
function startHand(room) {
  const d = deck();
  room.deck = d;
  room.community = [];
  room.pot = 0;
  room.stage = "preflop";
  room.currentBet = room.bigBlind;
  room.dealer = (room.dealer + 1) % room.players.length;
  room.turn = (room.dealer + 1) % room.players.length;
  room.players.forEach((p,i) => {
    p.cards = take(d,2);
    p.folded = false; p.allIn = false; p.bet = 0;
    const blind = i === (room.dealer+1)%room.players.length ? room.smallBlind : i === (room.dealer+2)%room.players.length ? room.bigBlind : 0;
    const paid = Math.min(p.stack, blind);
    p.stack -= paid; p.bet = paid; room.pot += paid;
  });
}
function advance(room) {
  room.players.forEach(p => { p.bet = 0; });
  room.currentBet = 0;
  if (room.stage === "preflop") { room.community.push(...take(room.deck,3)); room.stage="flop"; }
  else if (room.stage === "flop") { room.community.push(...take(room.deck,1)); room.stage="turn"; }
  else if (room.stage === "turn") { room.community.push(...take(room.deck,1)); room.stage="river"; }
  else { return settle(room); }
  room.turn = (room.dealer + 1) % room.players.length;
  room.acted = new Set();
}
function settle(room) {
  const live = room.players.filter(p => !p.folded);
  let winners = live;
  if (live.length > 1) {
    const ranked = live.map(p => ({p, score: handScore([...p.cards, ...room.community])}));
    ranked.sort((a,b)=>compare(b.score,a.score));
    winners = ranked.filter(x=>compare(x.score,ranked[0].score)===0).map(x=>x.p);
  }
  const share = Math.floor(room.pot / winners.length);
  winners.forEach((p,i)=>p.stack += share + (i===0 ? room.pot%winners.length : 0));
  room.lastResult = { winners: winners.map(p=>p.name), amount: room.pot };
  room.pot = 0; room.stage = "showdown"; room.turn = -1;
}
function publicRoom(room, viewerId) {
  return {
    id: room.id, name: room.name, game: room.game, stage: room.stage, pot: room.pot,
    community: room.community, currentBet: room.currentBet, turn: room.turn,
    players: room.players.map(p=>({id:p.id,name:p.name,stack:p.stack,bet:p.bet,folded:p.folded,cards:p.id===viewerId || room.stage==="showdown" ? p.cards : null})),
    yourCards: room.players.find(p=>p.id===viewerId)?.cards || [],
    lastResult: room.lastResult || null
  };
}
module.exports = { startHand, advance, settle, publicRoom };
